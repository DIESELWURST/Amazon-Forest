#pragma once
#include "mobs.hpp" 

void Update( std::vector<Baraba> & vectbar, Player & player,std::vector<Staroselci>&vectStaro,std::vector<Ogenj> & vectOg,std::vector<Drevo> & vectDrev);