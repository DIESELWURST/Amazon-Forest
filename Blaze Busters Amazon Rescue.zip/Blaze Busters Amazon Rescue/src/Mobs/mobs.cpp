#include "mobs.hpp"
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <time.h>
#include <iostream>
#include <cmath>
#include <vector>
#include <fstream>
#define SCREEN_WIDTH 1280 
#define SCREEN_HEIGHT 720

    
SDL_Window *globalWindow; //* globalna spremenljivka za window
SDL_Renderer *globalRenderer; //* globalna spremenljivka za renderer

void Level:: fillLevel (int st_levla) {
   
        st_Bar=5*st_levla;//*15*(i+1);
        st_Staro=10/st_levla;//*15/(i+1);
        st_Og=50*(st_levla);
   
}


int Menu::init() {
    // Nalaganje slike menija
    SDL_Surface *menuSurface = IMG_Load("assets/menu.png");
    if (!menuSurface) {
        printf("Error: Failed to load image\nSDL_Image Error: '%s'\n", IMG_GetError());
        return -1; // Dodana vrnjena vrednost v primeru napake pri nalaganju slike
    }

    // Ustvarjanje teksture menija
    SDL_Texture *menuTexture = SDL_CreateTextureFromSurface(globalRenderer, menuSurface);
    if (!menuTexture) {
        printf("Error: Failed to create texture\n");
        SDL_FreeSurface(menuSurface);
        return -1; // Dodana vrnjena vrednost v primeru napake pri ustvarjanju teksture
    }

    // Ustvarjanje pravokotnika za renderiranje menija
    SDL_Rect menuDst = { 
        .x = 0,
        .y = 0, 
        .w = SCREEN_WIDTH, 
        .h = SCREEN_HEIGHT
        };

    // Prikaz slike menija na zaslonu
    SDL_RenderCopy(globalRenderer, menuTexture, NULL, &menuDst);
    SDL_RenderPresent(globalRenderer);

    // Sprostitev uporabljenih virov
    SDL_FreeSurface(menuSurface);
    SDL_DestroyTexture(menuTexture);
    // Zanka za čakanje na pritisk tipke
    SDL_Event event;
    int mode = 0;
    while (true) {
        if (SDL_PollEvent(&event)) {
            if (event.type == SDL_KEYDOWN) {
                switch (event.key.keysym.scancode) {
                    case SDL_SCANCODE_1:
                        mode = 1;
                        break;
                    case SDL_SCANCODE_2:
                        mode = 2;
                        break;
                    case SDL_SCANCODE_3:
                        mode = 3;
                        break;
                    case SDL_SCANCODE_4:
                        mode = 4;
                        break;
                    default:
                        break;
                }
                break; // Izhod iz zanke, ko je pritisnjena tipka
            }
        }
        SDL_Delay(100); // Dodan delay, da se zmanjša obremenitev procesorja
    }

    return mode;
}

bool Mobs:: Borders(int minX, int maxX, int minY, int maxY)  { //* metoda za omejevanje premikov
            //* window borderji
                if (x>=maxX){
                    x=maxX-(x-maxX);
                }
                if(x<=minX) {
                    x=minX-x;
                }
                if (y>=maxY){
                  y=maxY-(y-maxY);
                }
                if(y<=minY) {
                    y=minY-y;
                }
            //*borderji za ta dvignjen platform ( kjer greš lahko gor po stopnicah)
                //* vse levo od stopnic
                if ((x>=550 && x<600)&&(y>=275&&y<=325)){
                    y=325+25;
                }
                if ((x>=525 && x<550)&&(y>=250&&y<=300)){
                    y=300;//* tuki ni +25 ker zgleda lepš
                }
                if ((x>=500 && x<550)&&(y>=250&&y<=275)){
                    y=250+25;
                }
                if ((x>=425 && x<550)&&(y>=200&&y<=275)){
                    y=275+25;
                }
                 if ((x>=400 && x<425)&&(y>=200&&y<=225)){
                    y=225;
                }
                if ((x>=325 && x<400)&&(y>=150&&y<=225)){
                    y=225;
                }
                if ((x>=275 && x<325)&&(y>=125&&y<=175)){
                    y=175;
                }
                if ((x>=175 && x<275)&&(y>=125&&y<=175)){
                    y=175;
                }
                if ((x>=75 && x<175)&&(y>=125&&y<=175)){
                    y=200;
                }
                if ((x>=0 && x<75)&&(y>=100&&y<=150)){
                    y=150;
                }
            //* vse desno od 1.stopnic
                if ((x>=650 && x<750)&&(y>=275&&y<=350)){
                    y=350;
                }
                if ((x>=750 && x<775)&&(y>=250&&y<=300)){
                    y=300;
                }
                 if ((x>=775 && x<850)&&(y>=225&&y<=275)){
                    y=275;
                }
                 if ((x>=825 && x<850)&&(y>=250&&y<=300)){
                    y=300;
                }
                 if ((x>=850 && x<875)&&(y>=275&&y<=325)){
                    y=325;
                }
                 if ((x>=875 && x<950)&&(y>=300&&y<=350)){
                    y=350;
                }
                 if ((x>=975 && x<1050)&&(y>=300&&y<=350)){ //* desno od stopnic
                    y=350;
                }
                   if ((x>=1025 && x<1075)&&(y>=225&&y<=300)){
                    y=300;
                }
                if ((x>=1025 && x<1050)&&(y>=75&&y<=200)){
                    x+=25; //* tuki lik proba it cez border z desne,zato ga ko prečka border samo pomaknemo v dovoljen prostor
                }
                if ((x>=1050 && x<1150)&&(y>=50&&y<=100)){
                    y=100;
                }
                if ((x>=1150 && x<1175)&&(y>=50&&y<=125)){
                    x-=25; //* tuki lik proba it cez border z leve,zato ga ko prečka border samo pomaknemo v dovoljen prostor
                }
                if ((x>=1125 && x<1250)&&(y>=75&&y<=150)){
                    y=150;
                } 

               
                

        return (x >= minX && x <= maxX && y >= minY && y <= maxY);
    }

Player:: Player() { 
    x=500;
    y=500;
    radius=60;
}



 bool Player:: Borders (int minX, int maxX, int minY, int maxY)  {
    return Mobs::Borders (minX,maxX,minY,maxY);
 }
#include <fstream>

void Player::Update() {
    const int movementSpeed = 25;
    const Uint8* currentKeyStates = SDL_GetKeyboardState(NULL); //* beremo/dobimo stanje tipkovnice
    if (currentKeyStates[SDL_SCANCODE_W])
        y -= movementSpeed;
    if (currentKeyStates[SDL_SCANCODE_A])
        x -= movementSpeed;
    if (currentKeyStates[SDL_SCANCODE_S])
        y += movementSpeed;
    if (currentKeyStates[SDL_SCANCODE_D])
        x += movementSpeed;

    Borders(0, SCREEN_WIDTH - 50, 0, SCREEN_HEIGHT - 50);
}


void Player:: Render() {
    SDL_Surface *mcSurface=IMG_Load("assets/player_front.png");
    if(!mcSurface){
         printf("Error: Failed to load player image\nSDL_Image Error: '%s'\n", IMG_GetError());        
    } 
    
    SDL_Texture *mc = SDL_CreateTextureFromSurface(globalRenderer , mcSurface);
    if(!mc){
        printf("Error: Failed to create texture\n");     
    }
    SDL_Rect mcDst = {
        .x = x, //* na katerem x-u bos postavu sliko
        .y = y, //* na keretem y-u bos postavu sliko
        .w = 50, //* širina slike, ki jo bomo dodali                      
        .h =  50,                      
    };
    SDL_FreeSurface(mcSurface);
    SDL_RenderCopy(globalRenderer, mc, NULL, &mcDst);
    SDL_RenderPresent(globalRenderer); //* outputa/nariše na screen sliko  (SAMO PR OBJEKTU KI SE ZADNJI RENDERA MEJ TO)
    
}


void Baraba:: fillBaraba(std::vector<Baraba>&vectBar){
    srand(time(NULL));
    for(std::vector<Baraba>::iterator it=vectBar.begin();it!=vectBar.end();it++){ //s to zanko napolnimo vektor z objekti Baraba
        int spawnQuotient= rand()%100;//* je spremenljivka s katero določimo, pri kateri luknji bo spawn objekta
        if(spawnQuotient<50){ //*če bo manjše od 50 se bo objekt (Baraba) spawnal na levi luknji
            it->x=100;
            it->y=200;
            it-> radius=60;
        }else { //* če bo >=50 bo imel spawn na desni luknji
            it->x=1200;
            it->y=150;
            radius=60;
        }
    }
}

bool Baraba:: Borders (int minX, int maxX, int minY, int maxY)  {
    return Mobs::Borders (minX,maxX,minY,maxY);
 }

void Baraba:: Update (std::vector<Baraba>&vectBar,Player &player,std::vector<Drevo> &vectDrev,int count) {
    int min_x=0; //* s tem gledamo ali je barabi bližji player ali katerkoli drevo
    int min_y=0;
    int movementSpeed=25;
     //s tem pogledamo če  je Player v radiju 
    int player_dist=std::sqrt(std::pow(player.getX() - x, 2) + std::pow(player.getY() - y, 2));//* gledamo če je player v radiju z uporabe formule za razdaljo med 2 točkama (d= sqrt( (x2-x1)^2 + (y2-y1)^2 ))
    if(player_dist<radius){ 
        min_y=player.getY();
    }
        
    int drev_dist=0;
        for(int i=0;i<vectDrev.size();i++){ //s tem pogledamo katero drevo je najbližje
            drev_dist=std::sqrt(pow((vectDrev[i].getX()-x),2) + pow((vectDrev[i].getY()-y),2));
            if(drev_dist<radius && drev_dist<player_dist){ // gledamo če je razdalja med drevesom in barabo manjša od radija
                min_x=vectDrev[i].getX();
                min_y=vectDrev[i].getY();
            } else { //* s tem se bo Baraba naključno premaknila nekam, če ničesar ni v njenem view-u
                x+=(rand()%3-1)*movementSpeed;
                y+=(rand()%3-1)*movementSpeed;    
            }
        }
    if (x < min_x) { //* pomikamo se proti namanjši vrednosti
        x += movementSpeed;
    } else if (x > min_x) {
        x -= movementSpeed;
    } 

    if (y < min_y) { 
        y += movementSpeed;
    } else if (y > min_y) {
        y -= movementSpeed;
    }
    Borders(0, SCREEN_WIDTH - 50, 0, SCREEN_HEIGHT - 50);

       for(int i=0;i<vectDrev.size();i++){ // s tem gledamo, če je radiju kakšno drevo
            if (std::sqrt(pow((vectDrev[i].getX()-x),2) + pow((vectDrev[i].getY()-y),2))< radius) { //* isto kot zgornja koda, ampak samo preverjamo za Staroselce
                 vectDrev[i].je_posekan= true;
            }
       }
       for(int i=0;i<vectBar.size();i++){
            if ((abs(vectBar[i].x-player.getX())< player.getRadius() && abs(vectBar[i].y-player.getY())< player.getRadius())){
                    vectBar.erase(vectBar.begin()+i); //* če sta player in 1 baraba sama izbiršemo barabo
            }
       }
}
void Baraba:: Render () {
     SDL_Surface *barSurface=IMG_Load("assets/baddie.png");
    if(!barSurface){
         printf("Error: Failed to load player image\nSDL_Image Error: '%s'\n", IMG_GetError());        
    } 
    
    SDL_Texture *bar = SDL_CreateTextureFromSurface(globalRenderer , barSurface);
    if(!bar){
        printf("Error: Failed to create texture\n");     
    }

    SDL_Rect barDst = {
        .x = x, //* na katerem x-u bos postavu sliko
        .y = y, //* na keretem y-u bos postavu sliko
        .w = 50, //* širina slike, ki jo bomo dodali                      
        .h = 50,                      
    };
    SDL_FreeSurface(barSurface);
    SDL_RenderCopy(globalRenderer, bar, NULL, &barDst);
    SDL_DestroyTexture(bar);
}


void Ogenj:: Render(){
   
   
     SDL_Surface *ogSurface=IMG_Load("assets/ogenj.png");
    if(!ogSurface){
         printf("Error: Failed to load player image\nSDL_Image Error: '%s'\n", IMG_GetError());        
    } 
    
    SDL_Texture *og = SDL_CreateTextureFromSurface(globalRenderer , ogSurface);
    if(!og){
        printf("Error: Failed to create texture\n");     
    }

    SDL_Rect ogDst = {
        .x = x, //* na katerem x-u bos postavu sliko
        .y = y, //* na keretem y-u bos postavu sliko
        .w = 80, //* širina slike, ki jo bomo dodali                      
        .h = 100,                      
    };

    SDL_FreeSurface(ogSurface);
    SDL_RenderCopy(globalRenderer, og, NULL, &ogDst);
    SDL_DestroyTexture(og);


}

void Ogenj:: fillOgenj(std::vector<Ogenj>&vectOg){
        for(int i=0;i<vectOg.size();i++){
                vectOg[i].y=rand()%600; //* 600 in 1200 , ker tako zgleda boljše
                vectOg[i].x=rand()%1210;
            Borders(0, SCREEN_WIDTH - 50, 0, SCREEN_HEIGHT - 50);
    }
}
 bool Ogenj:: Borders (int minX, int maxX, int minY, int maxY)  {
    return Mobs::Borders (minX,maxX,minY,maxY);
 }
void Ogenj:: Update (std::vector<Ogenj>&vectOg,Player &player,int count,int st_levla) { 
       if (abs(x-player.getX())<player.getRadius() && abs(y-player.getY())<player.getRadius() ) { //* samo pogledamo če je razdalja med playerjem in ognjem manjša od radija playerja
                vectOg.erase(vectOg.begin()+count);//* če je izbrišemo ogenj ven iz vectOg
            }
            Borders(0, SCREEN_WIDTH - 50, 0, SCREEN_HEIGHT - 50);
            if(vectOg.size() <=5){ //* s tem povzročimo, da se ognji refillajo, ko jih ostane 5
            vectOg.resize(50*st_levla);
            fillOgenj(vectOg);
        }

}

void Staroselci :: fillStaro (std::vector<Staroselci>&vectStaro) {
    int spawnQuotient;//* s tem določemo na kateremu izmed 4 možnih spwanov se bo pojavil 1 staroselec
    for(std::vector<Staroselci>:: iterator it=vectStaro.begin();it!=vectStaro.end();it++){
        spawnQuotient=rand()%100;
        if(spawnQuotient>=0 && spawnQuotient<25){
            it->x=100;
            it->y=100;
            it->radius=60;
        } else if (spawnQuotient>=25 && spawnQuotient<49){
            it->x=100;
            it->y=600;
            it->radius=60;
        }else if (spawnQuotient>=50 && spawnQuotient<75){
            it->x=1200;
            it->y=50;
            it->radius=60;
        }else if (spawnQuotient>=75 && spawnQuotient<99){
            it->x=1125;
            it->y=575;
            it->radius=60;
        }
    }
}
bool Staroselci:: Borders (int minX, int maxX, int minY, int maxY)  {
    return Mobs::Borders (minX,maxX,minY,maxY);
 }

void Staroselci:: Render(){
    SDL_Surface *staroSurface=IMG_Load("assets/goodie.png");
    if(!staroSurface){
         printf("Error: Failed to load player image\nSDL_Image Error: '%s'\n", IMG_GetError());        
    } 
    
    SDL_Texture *staro = SDL_CreateTextureFromSurface(globalRenderer , staroSurface);
    if(!staro){
        printf("Error: Failed to create texture\n");     
    }

    SDL_Rect StaroDst = {
        .x = x, //* na katerem x-u bos postavu sliko
        .y = y, //* na keretem y-u bos postavu sliko
        .w = 50, //* širina slike, ki jo bomo dodali                      
        .h = 50,                      
    };
    SDL_FreeSurface(staroSurface);
    SDL_RenderCopy(globalRenderer, staro, NULL, &StaroDst);
    SDL_DestroyTexture(staro);
}
 void Staroselci:: Update (std::vector<Baraba>& vectBar, std::vector<Ogenj>& vectOg, Player & player, std::vector<Staroselci>& vectStaro,int  st_staroselca){
    int min_x=vectBar[0].getX(); 
    int min_y=vectBar[0].getY();
    int movementSpeed=25;
    int barabeCount=0;
    for(int i=0;i<vectBar.size();i++){ //s tem pogledamo katera baraba je najbližja
        if((vectBar[i].getX()>=x-200 && vectBar[i].getX()<=x+200 )||( vectBar[i].getY()>=y-200 && vectBar[i].getY()<=y+200) ){ //* gledamo če je baraba oddaljena +- 200 z x-osi in y-osi
            if (abs(x-vectBar[i].getX())<min_x && abs(y-vectBar[i].getY())<min_y){ //* gledamo, če je razdalja do barabe manjša od radija Staroselcev
                min_x=vectBar[i].getX();
                min_y=vectBar[i].getY();
                barabeCount++; //* tuki še hkrati gledamo. če je v radiju Staroselca več kot ena baraba
            }
        }
    }
    for(int i=0;i<vectOg.size();i++){ //s tem pogledamo kateri ogenj je najbližji (ognji so bolj pomembni, zato se bodo prvo napotili k njim)
        if((vectOg[i].getX()>=x-200 && vectOg[i].getX()<=x+200 )|| (vectBar[i].getY()>=y-200 && vectBar[i].getY()<=y+200 )){
            if (abs(x-vectOg[i].getX())<min_x && abs(y-vectOg[i].getY())<min_y){
                min_x=vectOg[i].getX();
                min_y=vectOg[i].getY();
            }
        } else { //* s tem se bo Staroselec naključno premaknil nekam, če ničesar ni v njegovem view-u
            x+=(rand()%3-1)*movementSpeed;
            y+=(rand()%3-1)*movementSpeed;    
        }
    }

    if (x < min_x) { //* s tem se bližajo Staroselci po y-osi
        x += movementSpeed;
    } else if (x > min_x) {
        x -= movementSpeed;
    } 

    if (y < min_y) { 
        y += movementSpeed;
    } else if (y > min_y) {
        y -= movementSpeed;
    }
    Borders(0, SCREEN_WIDTH - 50, 0, SCREEN_HEIGHT - 50);

       for(int i=0;i<vectOg.size();i++){ // s tem staroselci pogasijo ogenj
            if (abs(vectOg[i].getX()-x)< radius && abs(vectOg[i].getY()-y)< radius) { //* isto kot zgornja koda, ampak samo preverjamo za Staroselce
                 vectOg.erase(vectOg.begin()+i);//* če je izbrišemo ogenj ven iz vectOg
            }
        }

        for(int i=0;i<vectBar.size();i++){ // s tem staroselci eliminirajo barabe
            if (abs(vectBar[i].getX()-x)< radius && abs(vectBar[i].getY()-y)< radius) { //* isto kot zgornja koda, ampak samo preverjamo za Staroselce
                 if(barabeCount>=2 && (abs(player.getX()-x)< radius && abs(player.getY()-y)< radius)) { //* preverjamo, če je 2+ barab v radiju in če je player
                    vectBar.erase(vectBar.begin()+i);//* če je izbrišemo eno barabo iz vectBar
                 } else if (barabeCount>=2 && !(abs(player.getX()-x)< radius && abs(player.getY()-y)< radius)){//* preverjamo, če 2+ barab in ni playerja
                        vectStaro.erase(vectStaro.begin()+i); //* če sta izbrišemo enega staroselca iz vectStaro
                 } else  {
                    vectBar.erase(vectBar.begin()+i); //* če je samo 1 barabo jo lahko izbriše 1 staroselec
                 }
            } 
             
        }
    
 }

 void Drevo:: fillDrev(std::vector<Drevo>&vectDrev){
    
   for(int i=0;i<vectDrev.size();i++){
        if(i==0){
            vectDrev[i].x=0;
            vectDrev[i].y=300;
        } else if (i==1){
            vectDrev[i].x=145;
            vectDrev[i].y=255;
        } else if (i==2){
          vectDrev[i].x=273;
          vectDrev[i].y=527;  
        } else if (i==3){
            vectDrev[i].x=700;
            vectDrev[i].y=500; 
        } else if (i==4){
            vectDrev[i].x=675;
            vectDrev[i].y=250; 
        } else if (i==5){
            vectDrev[i].x=1075;
            vectDrev[i].y=300; 
        } else if (i==6){
            vectDrev[i].x=1175;
            vectDrev[i].y=550; 
        } else if (i==7){
            vectDrev[i].x=1210;
            vectDrev[i].y=200; 
        }
        vectDrev[i].je_posekan=false;
   }

 }
 
    void Drevo::Render(int i) {
    if (!je_posekan) return;

    const char * fileNames[] = {
        "assets/drevo1.png",
        "assets/drevo2.png",
        "assets/drevo3.png",
        "assets/drevo4.png",
        "assets/drevo5.png",
        "assets/drevo6.png",
        "assets/drevo7.png",
        "assets/drevo8.png"
    };

    SDL_Rect sizes[] = {
        {x, y, 125, 256},
        {x, y, 201, 180},
        {x, y, 150, 150},
        {x, y, 140, 170},
        {x, y, 200, 200},
        {x, y, 150, 180},
        {x, y, 120, 150},
        {x, y, 70, 220}
    };

    SDL_Surface *drevSurface = IMG_Load(fileNames[i]);
    SDL_Texture *drev = SDL_CreateTextureFromSurface(globalRenderer, drevSurface);
    SDL_Rect StaroDst = sizes[i];

    SDL_FreeSurface(drevSurface);
    SDL_RenderCopy(globalRenderer, drev, NULL, &StaroDst);
    SDL_DestroyTexture(drev);
}

void Back:: Start(){
    //* SDL_window je samo nov tab, ki se odpre
        globalWindow = SDL_CreateWindow("Blaze Busters: Amazon Rescue", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, 0);
    if(!globalWindow){
        printf("Error: Failed to open window\nSDL Error: '%s'\n", SDL_GetError());
       
    }
    //*SDL_Renderer je pa dobesedno plac na katerega bomo risal
        globalRenderer = SDL_CreateRenderer(globalWindow, -1, SDL_RENDERER_ACCELERATED );
    if(!globalRenderer){
        printf("Error: Failed to create renderer\nSDL Error: '%s'\n", SDL_GetError());
    }  
}
void Back:: Render() {
           //* surface samo predstavlja sliko v pomnilniku
    SDL_Surface *backingSurface = IMG_Load("assets/back.png");
    if(!backingSurface){
        printf("Error: Failed to load image\nSDL_Image Error: '%s'\n", IMG_GetError());
    }

    //* texture je samo bolj optimiziran surface ( render in surface v enem)
    SDL_Texture *backing = SDL_CreateTextureFromSurface(globalRenderer, backingSurface);
    if(!backing){
        printf("Error: Failed to create texture\n");      
    }

    //* samo deklariral smo strukturo pravokotnik (rectangle), ki nam pove kje bomo rederal sliko
    SDL_Rect backingDst = {
        .x = 0, //* na katerem x-u bos postavu sliko
        .y = 0, //* na keretem y-u bos postavu sliko
        .w = SCREEN_WIDTH, //* širina slike, ki jo bomo dodali                      
        .h =  SCREEN_HEIGHT,  //* višina slike, ki jo bomo dodali                     
    };

        SDL_FreeSurface(backingSurface);//* sprosti prostor v pomnilniku, ki ga je zasedel surface     
        SDL_SetRenderDrawColor(globalRenderer, 42, 98, 61, 1); //* rederer nastav na barve rgba (r,g,b,a- svetloba)
        SDL_RenderCopy(globalRenderer, backing, NULL, &backingDst);//* samo še enkrat prekopira texture na render   
        SDL_DestroyTexture(backing); 
}
