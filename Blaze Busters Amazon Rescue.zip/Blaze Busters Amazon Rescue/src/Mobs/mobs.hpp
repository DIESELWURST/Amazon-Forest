#pragma once
#include <vector>
#include <SDL2/SDL_image.h>

class Level {
public:
    int st_Bar,st_Og,st_Staro;
    int getBar() const { return st_Bar;}
    int getOg() const { return st_Og;}
    int getStaro() const { return st_Staro;}
    void fillLevel( int st_levla);
};


class Menu {
public:
    int init();
    
};

class Mobs { // abstraktni razred iz katerega bomo izpeljevali druge entity-e
protected:
    int x,y;// kje se nahaja središčnica kroga
    int radius;
    int movementSpeed;
public:  
    int getX() const { return x; }
    int getY() const { return y; }
    int getRadius() const { return radius; }
    int getSpeed() const { return movementSpeed;}
    bool Borders(int minX, int maxX, int minY, int maxY)  ;
};



class Drevo: public Mobs {
public:
    bool je_posekan;
    void Render(int stevilo_Drevesa);
    void fillDrev(std::vector<Drevo>&vectDrev);
};

class Player: public Mobs {
public:
    Player(); //* metoda za risanje  
    void Render();
    void Update ();
    bool Borders(int minX, int maxX, int minY, int maxY)  ; //* metoda za omejevanje premikov (const je tm samo, da povem da ne bomo spremenil vrednosti ničesar)
};
class Baraba : public Mobs {
public:
    std::vector<Baraba> vectBar;
    void fillBaraba(std::vector<Baraba>&vectBar);
    void Render();
    void Update (std::vector<Baraba>&vectBar,Player &player,std::vector<Drevo> & vectDrev,int st_barabe);
    bool Borders(int minX, int maxX, int minY, int maxY);//* metoda za omejevanje premikov (const je tm samo, da povem da ne bomo spremenil vrednosti ničesar)
};

class  Back: public Mobs {
public:
    void Render();
    void Start();
};



class Ogenj: public Mobs {
public:
    void Render ();
    void Update (std::vector<Ogenj>&vectOg,Player &player,int st_ognja,int st_levla);
    void fillOgenj(std::vector<Ogenj>&vectOg);
    bool Borders(int minX, int maxX, int minY, int maxY);
};
class Staroselci: public Mobs {
public:
    void Render();
    void Update(std::vector<Baraba>&vectBar,std::vector<Ogenj>&vectOg,Player &player, std::vector<Staroselci> & vectStaro,int  st_staroselca);
    void fillStaro(std::vector<Staroselci>&vectStaro);
    bool Borders(int minX, int maxX, int minY, int maxY);
};



