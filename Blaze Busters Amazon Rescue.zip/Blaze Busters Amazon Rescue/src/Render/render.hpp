#pragma once

#include "mobs.hpp"

void Render(std::vector<Baraba>&vectBar, Player &player,std::vector<Staroselci> &vectStaro, std::vector<Ogenj> &vectOg,int st_Ognjev,std::vector<Drevo> & vectDrev,int st_levla);
