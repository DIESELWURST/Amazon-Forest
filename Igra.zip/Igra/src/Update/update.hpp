#pragma once
#include "mobs.hpp" 

void Update();