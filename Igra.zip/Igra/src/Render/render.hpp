#pragma once

#include "mobs.hpp"

void Render();
