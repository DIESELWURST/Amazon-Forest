#pragma once
#include <vector>
class Mobs { // abstraktni razred iz katerega bomo izpeljevali druge entity-e
protected:
    int x,y;// kje se nahaja središčnica kroga
    int radius;
public:  
    void Render(); //* metoda za risanje  
    int getX() const { return x; }
    int getY() const { return y; }
    int getRadius() const { return radius; }
};

class Player: public Mobs {
public:
    Player();
    void Render();
    bool Borders(int minX, int maxX, int minY, int maxY)  ; //* metoda za omejevanje premikov (const je tm samo, da povem da ne bomo spremenil vrednosti ničesar)
};


class Baraba : public Mobs {
public:
    std::vector<Baraba> vectBar;
    void fillBaraba(std::vector<Baraba>&vectBar);
    void Render(Player &player);
    void Borders(int minX, int maxX, int minY, int maxY);//* metoda za omejevanje premikov (const je tm samo, da povem da ne bomo spremenil vrednosti ničesar)
};

class  Back: public Mobs {
public:
    void Render();
    void Start();
};



