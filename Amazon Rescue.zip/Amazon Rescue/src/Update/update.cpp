#include "mobs.hpp"

//* funkicja, ki posodobila pozicije likov
void Update (){
    Player player;
    player.Update();
} 


