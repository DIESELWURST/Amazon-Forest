#pragma once

#include "mobs.hpp"

void Render(std::vector<Baraba>&vectBar, Player &player);
