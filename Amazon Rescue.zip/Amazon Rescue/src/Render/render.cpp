#include "render.hpp"
#include "mobs.hpp"
#include <vector>
#include <iterator>
#include <iostream>
#include <SDL2/SDL_image.h>

void Render(std::vector<Baraba>&vectBar,Player &player) { //* je funkcija, ki izpiše vse like
    Back back;
    back.Render();
    for(std::vector<Baraba>::iterator it=vectBar.begin();it!=vectBar.end();it++){//* izriše vsak element vektorja
        it->Render(player); //* tuki pa polega tega, da izrpe vsak posamezen element, ga tudi pomakne bližje playerju
    }
    player.Render();
    SDL_Delay(50);
}

